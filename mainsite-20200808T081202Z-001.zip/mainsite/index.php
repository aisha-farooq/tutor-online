<?php include('header.php'); ?>        
        <div class="banner-wrapper" style="">
            <section class="banner-one banner-carousel__one no-dots owl-theme owl-carousel">
                <div class="banner-one__slide banner-one__slide-one">
                    <div class="container">
                        <div class="banner-one__bubble-1"></div><!-- /.banner-one__bubble- -->
                        <div class="banner-one__bubble-2"></div><!-- /.banner-one__bubble- -->
                        <div class="banner-one__bubble-3"></div><!-- /.banner-one__bubble- -->
                        <img src="assets/images/slider-1-scratch.png" alt="" class="banner-one__scratch">
                        <img src="assets/images/slider-1-person-1.png" class="banner-one__person" alt="">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <h3 class="banner-one__title banner-one__light-color">We Can <br>
                                    Teach You</h3><!-- /.banner-one__title -->
                                <p class="banner-one__tag-line">are you ready to learn?</p><!-- /.banner-one__tag-line -->
                                <a href="#" class="thm-btn banner-one__btn">Learn More</a>
                            </div><!-- /.col-xl-12 -->
                        </div><!-- /.row -->
                    </div><!-- /.container -->
                </div><!-- /.banner-one__slide -->
                <div class="banner-one__slide banner-one__slide-two">
                    <div class="container">
                        <div class="banner-one__bubble-1"></div><!-- /.banner-one__bubble- -->
                        <div class="banner-one__bubble-2"></div><!-- /.banner-one__bubble- -->
                        <div class="banner-one__bubble-3"></div><!-- /.banner-one__bubble- -->
                        <img src="assets/images/slidermain1.png"alt="" class="banner-one__scratch">
                        <img src="assets/images/slidermain2.png" class="banner-one__person" alt="">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <h3 class="banner-one__title banner-one__light-color">We Can <br>
                                    Teach You</h3><!-- /.banner-one__title -->
                                <p class="banner-one__tag-line">are you ready to learn?</p><!-- /.banner-one__tag-line -->
                                <a href="about.php" class="thm-btn banner-one__btn">Learn More</a>
                            </div><!-- /.col-xl-12 -->
                        </div><!-- /.row -->
                    </div><!-- /.container -->
                </div><!-- /.banner-one__slide -->
            </section><!-- /.banner-one -->
             
        </div><!-- /.banner-wrapper -->
        
        
         <section class="about-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-two__content">
                            <div class="block-title text-left">
                                <h2 class="block-title__title">Welcome to online <br>
                                    learning center</h2><!-- /.block-title__title -->
                            </div><!-- /.block-title -->
                            <p class="about-two__text">Whatever subject you are aiming to learn, be it for an academic assessment, or for your self-advancement, we believe we have the perfect tutor for you                                don't look.</p><!-- /.about-two__text -->
                            <div class="about-two__single-wrap">
                                <div class="about-two__single">
                                    <div class="about-two__single-icon">
                                        <i class="kipso-icon-professor"></i><!-- /.kipso-icon-professor -->
                                    </div><!-- /.about-two__single-icon -->
                                    <div class="about-two__single-content">
                                        <p class="about-two__single-text">Start learning from
                                            our experts</p><!-- /.about-two__single-text -->
                                    </div><!-- /.about-two__single-content -->
                                </div><!-- /.about-two__single -->
                                <div class="about-two__single">
                                    <div class="about-two__single-icon">
                                        <i class="kipso-icon-knowledge"></i><!-- /.kipso-icon-professor -->
                                    </div><!-- /.about-two__single-icon -->
                                    <div class="about-two__single-content">
                                        <p class="about-two__single-text">Enhance your skills
                                            with us now</p><!-- /.about-two__single-text -->
                                    </div><!-- /.about-two__single-content -->
                                </div><!-- /.about-two__single -->
                            </div><!-- /.about-two__single-wrap -->
                            <a href="about.php" class="thm-btn">Learn More</a><!-- /.thm-btn -->
                        </div><!-- /.about-two__content -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-xl-6 d-flex justify-content-xl-end justify-content-sm-center">
                        <div class="about-two__image">
                            <span class="about-two__image-dots"></span><!-- /.about-two__image-dots -->
                            <img src="assets/images/group-of-people-in-a-meeting-3626622.jpg" alt="">
                            <div class="about-two__count">
                                <div class="about-two__count-text">Trusted by
                                    <span class="counter">9990</span></div><!-- /.about-two__count-text -->
                            </div><!-- /.about-two__count -->
                        </div><!-- /.about-two__image -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.about-two -->
                <section class="course-one__top-title home-one">
            <div class="container">
                <div class="block-title mb-0">
                    <h2 class="block-title__title">Explore our <br>
                        popular courses</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
            </div><!-- /.container -->
            <div class="course-one__top-title__curve"></div><!-- /.course-one__top-title__curve -->
        </section><!-- /.course-one__top-title -->

        <section class="course-one course-one__teacher-details home-one">
            <div class="container">
                <div class="course-one__carousel owl-carousel owl-theme">
                    <div class="item">
                        <div class="course-one__single color-1">
                            <div class="course-one__image">
                                <img src="assets/images/adult-blur-camera-casual-598917.jpg" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="course-details.php?cid=11" class="course-one__category">Photography</a><!-- /.course-one__category -->
                                                                <h2 class="course-one__title"><a href="course-details.php?cid=11">Basic Photography</a></h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                                                                                                                           </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
                                    <a href="course-details.html"><i class="far fa-clock"></i> 3 Month</a>
                                    <a href="course-details.html"><i class="far fa-folder-open"></i> 90 Lectures</a>
                                                                    </div><!-- /.course-one__meta -->
                                <a href="course-details.php?cid=11" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="course-one__single color-2">
                            <div class="course-one__image">
                                <img src="assets/images/two-brown-pencils-907607.jpg" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="course-details.php?cid=12" class="course-one__category">It & Software</a><!-- /.course-one__category -->
                                                               <h2 class="course-one__title"><a href="course-details.php?cid=12">SEO Skills</a></h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                    <!-- /.course-one__count -->
                                                                    </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
                                    <a href="course-details.html"><i class="far fa-clock"></i>3 Month</a>
                                    <a href="course-details.html"><i class="far fa-folder-open"></i> 90 Lectures</a>
                                                                    </div><!-- /.course-one__meta -->
                                <a href="course-details.php?cid=12" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="course-one__single color-3">
                            <div class="course-one__image">
                                <img src="assets/images/working-in-a-group-6224.jpg"alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="course-details.php?cid=13" class="course-one__category">Marketing</a><!-- /.course-one__category -->
                                                              <h2 class="course-one__title"><a href="course-details.php?cid=13">Marketing strategies</a></h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                    <!-- /.course-one__count -->
                                 
                                </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
                                    <a href="course-details.html"><i class="far fa-clock"></i> 3 Month</a>
                                    <a href="course-details.html"><i class="far fa-folder-open"></i> 90 Lecture</a>
                                                                   </div><!-- /.course-one__meta -->
                                <a href="course-details.php?cid=13" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.item -->
                                         <div class="item">
                        <div class="course-one__single color-4">
                            <div class="course-one__image">
                                <img src="assets/images/woman-using-smartphone-and-laptop-4549414.jpg" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="course-details.php?cid=10" class="course-one__category">Design</a><!-- /.course-one__category -->
                                                                <h2 class="course-one__title"><a href="course-details.php?cid=10">UI/UX design</a></h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                    <!-- /.course-one__count -->
                                                                 </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
                          <a href="course-details.html"><i class="far fa-clock"></i> 3 Month</a>
                   <a href="course-details.html"><i class="far fa-folder-open"></i> 90 Lecture</a>
                                    
                                </div><!-- /.course-one__meta -->
                <a href="course-details.php?cid=10" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="course-one__single color-5">
                            <div class="course-one__image">
                                <img src="assets/images/think-outside-of-the-box-6375.jpg" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="course-details.php?cid=9" class="course-one__category">Languages</a><!-- /.course-one__category -->
                                                               <h2 class="course-one__title"><a href="course-details.php?cid=9">Learn Chinese</a>
                                </h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                    <!-- /.course-one__count -->
                                                                    </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
                                    <a href="course-details.html"><i class="far fa-clock"></i> 3 Month</a>
                                    <a href="course-details.html"><i class="far fa-folder-open"></i>90 Lecture</a>
                                
                                </div><!-- /.course-one__meta -->
                                <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.item -->
                   
              </div><!-- /.course-one__carousel -->
            </div><!-- /.container -->
        </section><!-- /.course-one course-page -->
        
        <section class="video-two" style=" background-image:url('assets/images/accomplishment-ceremony-education-graduation-267885 (1).jpg');">
            <div class="container">
                <img src="assets/images/scratch-1-1.png" class="video-two__scratch" alt="">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="video-two__content">
                            <h2 class="video-two__title">Tutor Online one & only <br>
                                mission is to extend <br>
                                your knowledge base</h2><!-- /.video-two__title -->
                            <a href="about.php" class="thm-btn">Learn More</a><!-- /.thm-btn -->
                        </div><!-- /.video-two__content -->
                    </div><!-- /.col-lg-7 -->
                    <div class="col-lg-5 d-flex justify-content-lg-end justify-content-sm-start">
                                            </div><!-- /.col-lg-5 d-flex justify-content-end -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.video-two -->
               
        
        
        
        <section class="thm-gray-bg course-category-one">
           
            <div class="container-fluid text-center">
                         <div class="block-title text-center">
                    <h2 class="block-title__title">Browse online <br>
                        course categories</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="course-category-one__carousel owl-carousel owl-theme">
                    <div class="item">
                        <div class="course-category-one__single color-1">
                            <div class="course-category-one__icon">
                               <i class="fa fa-desktop" aria-hidden="true"></i>
                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">IT & Software</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                       

                    <div class="item">
                        <div class="course-category-one__single color-2">
                            <div class="course-category-one__icon">
                           <i class="fa fa-file-code" aria-hidden="true"></i>
                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">Development</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                   
                     <div class="item">
                        <div class="course-category-one__single color-4">
                            <div class="course-category-one__icon">
                             <i class="fa fa-camera" aria-hidden="true"></i>
                            </div><!-- /.course-category-one__icon -->
                  <h3 class="course-category-one__title">Photography</h3>
                  </div>
               </div><!-- /.item -->
                    <div class="item">
                        <div class="course-category-one__single color-5">
                            <div class="course-category-one__icon">
                     <i class="fa fa-handshake" aria-hidden="true"></i>
                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">Marketing</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                    
                          <div class="item">
                        <div class="course-category-one__single color-2">
                            <div class="course-category-one__icon">
                               <i class="fa fa-language" aria-hidden="true"></i>                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">Languages</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                                       <div class="item">
                        <div class="course-category-one__single color-5">
                            <div class="course-category-one__icon">
                           <i class="fa fa-briefcase" aria-hidden="true"></i>                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">Business</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                     <div class="item">
                        <div class="course-category-one__single color-1">
                            <div class="course-category-one__icon">
                           <i class="fa fa-text-height" aria-hidden="true"></i>-->
                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">Design</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                     <div class="item">
                        <div class="course-category-one__single color-4">
                            <div class="course-category-one__icon">
                               <i class="fa fa-search" aria-hidden="true"></i>
                            </div><!-- /.course-category-one__icon -->
                            <h3 class="course-category-one__title">SEO</h3>
                            <!-- /.course-category-one__title -->
                        </div><!-- /.course-category-one__single -->
                    </div><!-- /.item -->
                </div><!-- /.course-category-one__carousel owl-carousel owl-theme -->
                <a href="courses.php" class="thm-btn">View Courses in Detail</a><!-- /.thm-btn -->
            </div><!-- /.container-fluid -->
        </section><!-- /.thm-gray-bg course-category-one -->
        
        
        
        <section class="cta-three">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 clearfix">
                        <img src="assets/images/person-writing-on-notebook-4144923.jpg" class="cta-three__image" alt="">
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="cta-three__content">
                            <div class="block-title text-left">
                                <h2 class="block-title__title">Benefits of learning
                                    with Tutor Online</h2><!-- /.block-title__title -->
                            </div><!-- /.block-title -->
                            <p class="cta-three__text">TUTOR ONLINE makes the whole process of finding tutors swift and secure. Join TUTOR ONLINE and find your ideal tutor today!.You get to select from a much wider pool of tutors as the distance to the tutor is no longer a limiting factor.</p>
                            <!-- /.cta-three__text -->
                            <div class="cta-three__single-wrap">
                                <div class="cta-three__single">
                                <img src="assets/images/school.png" width="80px" height="80px" >
                                                              <p class="cta-three__single-text">Professional
                                        Courses</p><!-- /.cta-three__single-text -->
                                </div><!-- /.cta-three__single -->
                                <div class="cta-three__single">
                      <img src="assets/images/online-class.png" width="80px" height="80px" >                                    <p class="cta-three__single-text">Live
                                        Learning</p><!-- /.cta-three__single-text -->
                                </div><!-- /.cta-three__single -->
                                <div class="cta-three__single">
     <img src="assets/images/teacher.png" width="80px" height="80px" >                                    <p class="cta-three__single-text">Expert
                                        Teachers</p><!-- /.cta-three__single-text -->
                                </div><!-- /.cta-three__single -->
                            </div><!-- /.cta-three__single-wrap -->
                            <a href="about.php" class="thm-btn">Learn More</a><!-- /.thm-btn -->
                        </div><!-- /.cta-three__content -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.cta-three -->
        
            <section class="cta-four " style="background-image:url('assets/images/bi.jpg');">
            <img src="assets/images/circle-stripe-1.png" class="cta-four__stripe" alt="">
            <img src="assets/images/line-stripe-1.png" class="cta-four__line" alt="">
            <div class="container text-center">
                <div class="block-title">
                    <h2 class="block-title__title">We Provides you  best teachers <br>
                        in every subject</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <p class="cta-four__text" style="margin-bottom:120px;">TUTOR ONLINE has one simple objective: To bring tutors and students together.We understand finding a tutor is not always easy task.Wether searching for Primary, O level, or any other skill, We strive to make the process as simple as possible.Take classes from any teacher all over the globe. </p><!-- /.cta-four__text -->
            </div><!-- /.container text-center -->
        </section><!-- /.cta-four -->
        <section class="mailchimp-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="mailchimp-one__content">
                            <div class="mailchimp-one__icon">
                     <i class="fa fa-envelope" aria-hidden="true"></i>
                               
                            </div><!-- /.mailchimp-one__icon -->
                            <h2 class="mailchimp-one__title">Get latest courses <br>
                                updates by signing up</h2><!-- /.mailchimp-one__title -->
                        </div><!-- /.mailchimp-one__content -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6 d-flex">
                        <div class="my-auto">
      <form  action="../assets/inc/sendmail.php"class="mailchimp-one__form mc-form" data-url="https://gmail.us10.list-manage.com/subscribe/post?u=a4e9fc7ae355834f1f143de54&amp;id=77404a2293">
                                <input type="email" id="mc-email" placeholder="Enter your email ">
                                <button type="submit" class="thm-btn">Subscribe</button>
                            </form><!-- /.mailchimp-one__form -->
                            <div class="mc-form__response"></div><!-- /.mc-form__response -->
                        </div><!-- /.my-auto -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.mailchimp-one -->

        
           
         <?php include('footer.php'); ?>
             </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
           <form  class="search-popup__form" action="search.php" method="post">
                <input type="text" name="search" placeholder="Search Course Here....">
                <button type="submit" name="btnsearch"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
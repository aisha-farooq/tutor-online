 <?php
 
      $conn= mysqli_connect('localhost','root','','tutoronline');

if(!$conn){
	
	mysqli_error($conn);
	
}

?>
<?php include('header.php');?>
<body>
            <section class="inner-banner" style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                    
                      <li style="font-size:50px;" ><a href="index.php">Home</a><a href="teachers.php" >&nbsp;>&nbsp;Teachers</a></li>                </ul><!-- /.list-unstyled -->
                           </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="team-one team-page">
            <div class="container">
            
        
                <div class="row" >
                     <?php  
      $query = "SELECT * FROM teacher";  
        $result = mysqli_query($conn, $query);  
      if(mysqli_num_rows($result) > 0)  
                {  
                     while($ftch = mysqli_fetch_array($result))  
                     {  
                ?>
                    <div class="col-lg-3" >
                        <div class="team-one__single"  >
                            <div class="team-one__image">
 <img src="<?php echo $ftch['timage']; ?>" width="206px" height="206px;" alt="" style="border-radius:50%;">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                      <h2 class="team-one__name"><?php echo $ftch['tname']; ?></h2>
                                <!-- /.team-one__name -->
             <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                     <p class="team-one__text"><?php echo substr($ftch['tintro'], 0 ,75) ?></p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                            <div class="team-one__social">
  <a href="teacherdetail.php?tid=<?php echo $ftch['tid']; ?> " style="font-size:20px;">See Preview</a>                                
                                                           </div><!-- /.team-one__social -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                    <?php 
                      
                      }
                      }
                      ?>  
                </div><!-- /.row -->
                <div class="post-pagination mt-5" >
                                      
                                            </div><!-- /.post-pagination -->

            </div><!-- /.container -->

                
         
        </section><!-- /.team-one team-page -->
        <div class="cta-two">
            <div class="container-fluid">
                <div class="row no-gutters">
                    <div class="col-lg-6 thm-base-bg">
                        <div class="cta-two__single">
                            <div class="cta-two__icon">
<img src="assets/images/teacher.png" width="150px" height="150px">
                            </div><!-- /.cta-two__icon -->
                            <div class="cta-two__content">
                                <h2 class="cta-two__title">Become an teacher</h2><!-- /.cta-two__title -->
                                <p class="cta-two__text">We have developed a new platform for tutors to deliver online
lessons. If you want to offer online course, Register Yourself.</p><!-- /.cta-two__text -->
                                <a href="register.php" class="thm-btn cta-two__btn">Start Teaching</a><!-- /.thm-btn cta-two__btn -->
                            </div><!-- /.cta-two__content -->
                        </div><!-- /.cta-two__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6 thm-base-bg-2">
                        <div class="cta-two__single">
                            <div class="cta-two__icon">
                         <img src="assets/images/join.png" width="150px" height="150px">
                            </div><!-- /.cta-two__icon -->
                            <div class="cta-two__content">
                                <h2 class="cta-two__title">Join our community</h2><!-- /.cta-two__title -->
                                <p class="cta-two__text">We have developed a new platform for students to attend online
lessons.If you want to Start Learning Register Now.</p><!-- /.cta-two__text -->
                                <a href="register.php" class="thm-btn cta-two__btn">Start Learning</a><!-- /.thm-btn cta-two__btn -->
                            </div><!-- /.cta-two__content -->
                        </div><!-- /.cta-two__single -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row no-gutters -->
            </div><!-- /.container-fluid -->
        </div><!-- /.cta-two -->
        <?php include('footer.php'); ?>

    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
           <form  class="search-popup__form" action="search.php" method="post">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit" name="btnsearch"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
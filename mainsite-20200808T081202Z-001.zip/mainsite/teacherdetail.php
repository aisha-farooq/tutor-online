<?php include('header.php'); ?> 
 <?php
	if($_GET){
	$tid = $_GET['tid'];	  
                $query = "SELECT * FROM teacher where tid=$tid;";  
                $result = mysqli_query($conn, $query);  
            $ftch = mysqli_fetch_array($result); 
                  
                   }
                ?>
	


        <section class="inner-banner" style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                      <li style="font-size:50px;" ><a href="index.php">Home</a><a href="teacherdetail.php" >&nbsp;>&nbsp;Teacher detail</a></li>                   
                </ul><!-- /.list-unstyled -->
                <h2 class="inner-banner__title"><?php echo $ftch['tname']; ?></h2><!-- /.inner-banner__title -->
            </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="team-details">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-lg-5">
                        <div class="team-details__content">
                            <h2 class="team-details__title">Introduction</h2><!-- /.team-details__title -->
                            <p class="team-details__text"><?php echo $ftch['tintro']; ?></p><!-- /.team-details__text -->
                            

                       
                        </div><!-- /.team-details__content -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?php echo $ftch['timage']; ?>" height="300px" width="300px;" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                             <h2 class="team-one__name"><a href="team-details.html"><?php echo $ftch['tname']; ?></a></h2>
                                <!-- /.team-one__name -->
              <h2 class="team-one__designation">Teacher</h2><!-- /.team-one__designation -->
               <p class="team-one__designation" style="color:gray;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp; <?php echo $ftch['tcountry']; ?></p>
                <p class="team-one__designation"><i class="fa fa-envelope" aria-hidden="true" ></i>&nbsp;<?php echo $ftch['temail']; ?></p>
             


                            </div><!-- /.team-one__content -->
                                                    </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.team-details -->
        <section class="course-one__top-title thm-gray-bg">
<?php
         $name=$ftch['tname'];	  
                $query = "SELECT * FROM course where cteachby='$name';";  
                $result = mysqli_query($conn, $query); 
            $ftchh = mysqli_fetch_array($result); 
           
                    ?>

            <div class="container">
                <div class="block-title mb-0">
                    <h2 class="block-title__title">Other Courses Teach By <?php echo $ftch['tname']; ?> <br>
                       </h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
            </div><!-- /.container -->
        </section><!-- /.course-one__top-title -->

        <section class="course-one course-one__teacher-details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="course-one__single">
                            <div class="course-one__image">
                                <img src="<?php echo $ftchh['cimage']; ?>" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
                                <a href="#" class="course-one__category"><?php echo $ftchh['cmaincategory']; ?></a><!-- /.course-one__category -->
                                <div class="course-one__admin">
                                    <img src="<?php echo $ftch['timage']; ?>" alt="">
                                    by <a href="teacher-details.html"><?php echo $ftchh['cteachby']; ?></a>
                                </div><!-- /.course-one__admin -->
                                <h2 class="course-one__title"><a href="course-details.html"><?php echo $ftchh['cname']; ?></a></h2>
                                <!-- /.course-one__title -->
                                                               <div class="course-one__meta">
                                    <a href="course-details.html"><i class="far fa-clock"></i> <?php echo $ftchh['cduration']; ?>Duration</a>
                                                                        <a href="course-details.html"><?php echo $ftchh['cfee']; ?></a>
                                </div><!-- /.course-one__meta -->
                                <a href="courses.php" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->
                    </div><!-- /.col-lg-4 -->
                                    </div><!-- /.course-one__carousel -->
            </div><!-- /.container -->
        </section><!-- /.course-one course-page -->
         <?php include('footer.php'); ?>    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
           <form  class="search-popup__form" action="search.php" method="post">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit" name="btnsearch"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
<?php include('header.php'); ?>
        <section class="inner-banner" style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                  <li style="font-size:50px;" ><a href="index.php">Home</a><a href="faq.php" >&nbsp;>&nbsp;FAQ</a></li>
                  
                </ul><!-- /.list-unstyled -->
                           </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="faq-one">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">What is Tutor online?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">Tutor online is an online learning platform for everyone who has an
account registered. Tutor online works with tutors to make some of their
courses available online, and offers courses in physics,
 medicine, mathematics, business,languages,photography,
computer science, and other subjects.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Are the courses on tutor online free?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">Some tutor online courses are free, but most individual courses, which
take around four to six weeks to complete, are not free..</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">How do I register as a tutor?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">To create a student/tutor account on Tutor online, please click on the
register button. It is free to create a Tutor online account.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">How long are tutor online courses?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">Every course has a specific duration associated with it. Some courses
have a suggested time commitment usually of between 4 and 10 weeks,
committing a few hours of study a week.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">How many courses can one take at a time in tutor online?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">It is up to you. You can attend one course or multiple courses. Tutor
online allows multiple sessions, so you can surely do multiple courses at
a time.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="faq-one__single">
                            <div class="faq-one__icon">
                                <span>?</span>
                            </div><!-- /.faq-one__icon -->
                            <div class="faq-one__content">
                                <h2 class="faq-one__title">Can I put tutor online course on my resume?</h2><!-- /.faq-one__title -->
                                <p class="faq-one__text">If you have taken courses that have taught you something that will help
you on the job include them on your resume.</p><!-- /.faq-one__text -->
                            </div><!-- /.faq-one__content -->
                        </div><!-- /.faq-one__single -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.faq-one -->
        <?php include('footer.php'); ?>
    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
            <form action="#" class="search-popup__form">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
<?php   
include('conn.php');
 if(isset($_POST['submit']))
  {
      $tname=$_POST['tname'];
	  $tlastname=$_POST['tlastname'];
	  $temail=$_POST['temail'];
	  $tpwd=$_POST['tpwd'];
	  $tintro=$_POST['editort'];
	  $tgender=$_POST['tgender'];
      $timage = "../pic/".$_FILES['takephoto']['name'];
	move_uploaded_file($_FILES['takephoto']['tmp_name'],$timage);
	 $tcountry=$_POST['tcountry'];
 $token=substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRSTUVWXYZ",5)),0,10);

      
  
$query = "SELECT * FROM teacher WHERE tname= '$tname' OR temail='$temail'";
$result = mysqli_query($conn,$query);
if ($result) {
  if (mysqli_num_rows($result) > 0) 
  {
   echo" <script> alert('User Name or Email Already Exist');</script>";

  }
   else{
     $qry="INSERT INTO teacher(tname,tlastname,temail,tpwd,tintro,tgender,timage,tcountry,token)values('$tname','$tlastname','$temail','$tpwd','$tintro','$tgender','$timage','$tcountry','$token')";  
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
}
   }
   }		  
?>  
<?php   
 if(isset($_POST['submitt']))
  {
      $sname=$_POST['sname'];
	  $slastname=$_POST['slastname'];
	  $semail=$_POST['semail'];
	  $spwd=$_POST['spwd'];
	  $sintro=$_POST['editors'];
	  $sgender=$_POST['sgender'];
      $simage = "../pic/".$_FILES['takephoto']['name'];
	move_uploaded_file($_FILES['takephoto']['tmp_name'],$simage);
	 $scountry=$_POST['scountry'];
	  $token=substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRSTUVWXYZ",5)),0,10);

	 
      $query = "SELECT * FROM student WHERE sname= '$sname' OR semail='$semail'";
$result = mysqli_query($conn,$query);
if ($result) {
  if (mysqli_num_rows($result) > 0) 
  {
   echo" <script> alert('User Name Already Exist');</script>";
  }
   else{  
     $qry="INSERT INTO student(sname,slastname,semail,spwd,sintro,sgender,simage,scountry,token)values('$sname','$slastname','$semail','$spwd','$sintro','$sgender','$simage','scountry','$token')";  
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
	else{
	  echo" <script> alert('Thanks For Registration');</script>";
	}
 }
 }
   } 		  
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tutor Online</title>
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/images/favicons/site.webmanifest">

    <!-- plugin scripts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,500i,600,700,800%7CSatisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome-free-5.11.2-web/css/all.min.css">
    <link rel="stylesheet" href="assets/plugins/kipso-icons/style.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vegas.min.css">

    <!-- template styles -->
    <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        <style>
.register{
    
    margin-top: 3%;
    padding: 3%;
    background-color:#022c46;
}
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 4%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 200px;;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #f8f9fa;
    border-top-left-radius: 10% 50%;
    border-bottom-left-radius: 10% 50%;
}
.register-left img{
    margin-top: 15%;
    margin-bottom: 5%;
    width: 25%;
    -webkit-animation: mover 2s infinite  alternate;
    animation: mover 1s infinite  alternate;
}
@-webkit-keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
@keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
.register-left p{
    font-weight: lighter;
    padding: 12%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    
    margin-top:5%;
    margin-bottom:20px;
    margin-left:280px;
    border: none;
    border-radius: 1.5rem;
    background: #f56e2c;
    color: #fff;
    font-weight: 600;
    width: 60%;
    height:40px;
    cursor: pointer;
}
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #f56e2c;
    border-radius: .5rem;
    width: 28%;
    float: right;
    padding:10px;
    }
.register .nav-tabs .nav-link{
    padding:2%;
    padding-bottom:35px;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: .5rem;
    border-bottom-right-radius: .5rem;
    
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #0062cc;
    border: 2px solid #0062cc;
    border-top-left-radius: .5rem;
    border-bottom-left-radius: .5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #f56e2c;
}
</style>
</head>

<body>
    <div class="preloader"></div><!-- /.preloader -->
    <div class="page-wrapper">
        <div class="topbar-one">
            <div class="container">
                <div class="topbar-one__left">
                    <a href="#">tutoronline@gmail.com</a>
                    <a href="#">0300 0000000</a>
                </div><!-- /.topbar-one__left -->
                            </div><!-- /.container -->
        </div><!-- /.topbar-one -->
        <header class="site-header site-header__header-one site-header__inner-page ">
            <nav class="navbar navbar-expand-lg navbar-light header-navigation stricky">
                <div class="container clearfix">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="logo-box clearfix">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/images/logo-dark.png" class="main-logo" width="128" alt="Awesome Image" />
                        </a>
                        <div class="header__social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-facebook-square"></i></a>
                            <a href="#"><i class="fab fa-pinterest-p"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div><!-- /.header__social -->
                        <button class="menu-toggler" data-target=".main-navigation">
                            <span class="kipso-icon-menu"></span>
                        </button>
                    </div><!-- /.logo-box -->
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="main-navigation">
                        <ul class=" navigation-box">
                            <li class="current">
                                <a href="index.php">Home</a>
                             </li>
                            <li>
                                <a href="about.php">About Us</a>
                                  </li>
                            <li>
                                <a href="courses.php">Courses</a>
                               </li>
                            <li>
                                <a href="teachers.php">Teachers</a>
                                                           </li>
                                                       <li>
                                <a href="contact.php">Contact</a>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                    <div class="right-side-box">
                        <a class="header__search-btn search-popup__toggler" href="#"><i class="kipso-icon-magnifying-glass"></i>
                            <!-- /.kipso-icon-magnifying-glass --></a>
                    </div><!-- /.right-side-box -->
                </div>
                <!-- /.container -->
            </nav>
            <div class="site-header__decor">
                <div class="site-header__decor-row">
                    <div class="site-header__decor-single">
                        <div class="site-header__decor-inner-1"></div><!-- /.site-header__decor-inner -->
                    </div><!-- /.site-header__decor-single -->
                    <div class="site-header__decor-single">
                        <div class="site-header__decor-inner-2"></div><!-- /.site-header__decor-inner -->
                    </div><!-- /.site-header__decor-single -->
                    <div class="site-header__decor-single">
                        <div class="site-header__decor-inner-3"></div><!-- /.site-header__decor-inner -->
                    </div><!-- /.site-header__decor-single -->
                </div><!-- /.site-header__decor-row -->
            </div><!-- /.site-header__decor -->
        </header><!-- /.site-header -->
        <section class="inner-banner"  style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                     <li style="font-size:50px;" ><a href="index.php">Home</a><a href="register.php" >&nbsp;>&nbsp;Register</a></li>                                  </ul><!-- /.list-unstyled -->
                           </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="contact-info-one">
           	
   	<div class="container register " id="id01" style="margin-bottom:50px;">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="assets/images/preloader.gif" alt=""/>
                        <h3>Welcome</h3>
                        <p>TUTOR ONLINE has one simple objective: To bring tutors and students together.</p>
                        <a href="login.php"><input type="submit" name="" value="Login"/></a><br/>
                    </div>
                    <div class="col-md-9 register-right">
                        <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">As Student</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">As Teacher</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Register as Student</h3>
                                
                               <form method="post" enctype="multipart/form-data">
                       
                                <div class="row register-form">
                                    <div class="col-md-6">
             <div class="form-group">
           <input type="text" class="form-control" placeholder="First Name *" value=""name="sname" required="required" />
             </div>
                         <div class="form-group">
                <input type="email" class="form-control" placeholder="Email *" value="" name="semail" required="required"/>
                                        </div>
                                         <div class="form-group">
                <input type="text" class="form-control" placeholder="Country *" value="" name="scountry" required="required"/>
                                        <label class="mt-3"> Discription/Bio*</label>
                                        </div>

                                                     <div class="form-group" >
    <img src="assets/images/add-photo.png"  class="img-fluid" id="profileDisplay" onClick="triggerClick();" style="border:1px #f56e2c solid; margin-left:500px; margin-top:-200px; width:500px; height:150px;">
	<input type="file" style="display:none" name="takephoto" onChange="displayImage(this)" id="profileImage">                                        </div>

                                         
                                        
                                    </div>
                                    <div class="col-md-6">
                                       
                                        <div class="form-group">
                                            <input type="text"   name="slastname" class="form-control" placeholder="Last Name *" value="" required="required" />
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" placeholder="Password *" value="" name="spwd"/>
                                        </div>  
                                        
<div class="form-group">
                                            <div class="maxl">
                                                <label class="radio inline" > 
                           <input type="radio" name="sgender" value="male" checked >
                                                    <span> Male </span> 
                                                </label>
                                                <label class="radio inline"> 
                                                    <input type="radio" name="sgender" value="female">
                                                    <span>Female </span> 
                                                </label>
                                                 
                                            </div>
                                        </div>        
                                                                                                            </div>
                                                                                                             
                                </div>
                               

                                 <div class="row">
                                    <div class="col-8">
               
                                 <div class="form-group" style="margin-left:90px; margin-top:-140px;">
 <textarea class="form-control dis ckeditor " name="editors" placeholder="Discription/Bio*" ></textarea>
                                        </div> 
                                        <button type="submit" name="submitt"  class="btnRegister">Register</button>          </div>
                                        </div>
                                  </form>

                            </div>
                            <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <h3  class="register-heading">Register As Teacher</h3>
         <form method="post" enctype="multipart/form-data">
                       
                                <div class="row register-form">
                                    <div class="col-md-6">
             <div class="form-group">
           <input type="text" class="form-control" placeholder="First Name *" value=""name="tname" required="required" />
             </div>
                         <div class="form-group">
                <input type="email" class="form-control" placeholder="Email *" value="" name="temail" required="required"/>
                                        </div>
                                         
                                         <div class="form-group ">
                <input type="text" class="form-control" placeholder="Country *" value="" name="tcountry" required="required"/>
                <label class="mt-3"> Discription/Bio*</label>

                                        </div>

             
   <div class="form-group" >
    <img src="assets/images/add-photo.png"  class="img-fluid" id="profileDisplayy" onClick="triggerClickk();" style="border:1px #f56e2c solid; margin-left:500px; margin-top:-200px; width:500px; height:150px;">
	<input type="file" style="display:none" name="takephoto" onChange="displayImagee(this)" id="profileImagee">                                        </div>
                                         
                                        
                                    </div>
                                    <div class="col-md-6">
                                       
                                        <div class="form-group">
                                            <input type="text"   name="tlastname" class="form-control" placeholder="Last Name *" value="" required="required" />
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" placeholder="Password *" value="" name="tpwd"/>
                                        </div>  
                                        
<div class="form-group">
                                            <div class="maxl">
                                                <label class="radio inline" > 
                           <input type="radio" name="tgender" value="male" checked >
                                                    <span> Male </span> 
                                                </label>
                                                <label class="radio inline"> 
                                                    <input type="radio" name="tgender" value="female">
                                                    <span>Female </span> 
                                                </label>
                                            </div>                                        
                                        </div>  
                                   </div>
                                </div>
                                <div class="row">
                                    <div class="col-8">
               
                                 <div class="form-group" style="margin-left:90px; margin-top:-140px;">
 <textarea class="form-control dis ckeditor " name="editort" placeholder="Discription/Bio*" ></textarea>
                                        </div> 
                                        <button type="submit" name="submit"  class="btnRegister">Register</button>          </div>
                                        </div>
                                  </form>
                            </div>
                          
                                                    </div>
                    </div>
                </div>

         </div>
   	
   	
   	
        </section><!-- /.contact-one -->

                <?php include('footer.php'); ?>    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
            <form action="#" class="search-popup__form">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>
</html>
<script>
	function triggerClick(e) {
  document.querySelector('#profileImage').click();
}
function displayImage(e) {
  if (e.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e){
      document.querySelector('#profileDisplay').setAttribute('src', e.target.result);
    }
    reader.readAsDataURL(e.files[0]);
  }
}
	</script>
	<script>
	function triggerClickk(e) {
  document.querySelector('#profileImagee').click();
}
function displayImagee(e) {
  if (e.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e){
      document.querySelector('#profileDisplayy').setAttribute('src', e.target.result);
    }
    reader.readAsDataURL(e.files[0]);
  }
}
	</script>
	 <script src="../ckeditor/ckeditor.js"></script>
  <script>
        CKEDITOR.replace( 'editort' );
      </script>
 <script>
        CKEDITOR.replace( 'editors' );
      </script>

<?php include('header.php'); ?> 
 <?php
	if($_GET){
	$cid = $_GET['cid'];	  
                $query = "SELECT * FROM course where cid=$cid;";  
                $result = mysqli_query($conn, $query);  
            $ftch = mysqli_fetch_array($result); 
                   $teachby= $ftch['cteachby']; 
                   }
                ?>
	




        <section class="inner-banner" style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
                
                     <li style="font-size:50px;" ><a href="index.php">Home</a><a href="coursedetails.php" >&nbsp;>&nbsp;Course Detail</a></li>                </ul><!-- /.list-unstyled -->
                           </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="course-details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="course-details__content">
                            <p class="course-details__author">
<?php        
$login = "SELECT * FROM teacher WHERE tname = '$teachby' ";
$result = mysqli_query($conn,$login);
$row = mysqli_fetch_array($result);

?>
       <img src=" <?php echo $row['timage']; ?>" alt="">
                                by <a href="#"><?php echo $ftch['cteachby']; ?></a>
                            </p><!-- /.course-details__author -->

                            <div class="course-details__top">
                                <div class="course-details__top-left">
                                    <h2 class="course-details__title"><?php echo $ftch['cname']; ?></h2>
                                    <!-- /.course-details__title -->
                                                                    </div><!-- /.course-details__top-left -->
                                <div class="course-details__top-right">
                   <a href="#" class="course-one__category"><?php echo $ftch['cmaincategory']; ?></a><!-- /.course-one__category -->
                                </div><!-- /.course-details__top-right -->
                            </div><!-- /.course-details__top -->
                            <div class="course-one__image">
                                <img src="<?php echo $ftch['cimage']; ?>" alt="">
                               <!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->

                            <ul class="course-details__tab-navs list-unstyled nav nav-tabs" role="tablist">
                                <li>
                                    <a class="active" role="tab" data-toggle="tab" href="#overview">Overview</a>
                                </li>
                                <li>
                                    <a class="" role="tab" data-toggle="tab" href="#batch">Batch</a>
                                </li>

                                                                <li>
                                    <a class="" role="tab" data-toggle="tab" href="#review">Reviews</a>
                                </li>
                            </ul><!-- /.course-details__tab-navs list-unstyled -->
                            <div class="tab-content course-details__tab-content ">
                                <div class="tab-pane show active  animated fadeInUp" role="tabpanel" id="overview">
                    <p class="course-details__tab-text"><?php echo $ftch['cdiscription']; ?>                                </div><!-- /.course-details__tab-content -->
                    
                     

        <div class="tab-pane   animated fadeInUp" role="tabpanel" id="batch">
       <ul class="course-details__curriculum-list list-unstyled">
       <?php        
         echo   $cname=$ftch['cname'];
$login = "SELECT * FROM batch WHERE cname= '$cname' ";
$result = mysqli_query($conn,$login);
$row = mysqli_fetch_array($result);

?>
                                        <li>
                                            <div class="course-details__curriculum-list-left">
                                                <div class="course-details__meta-icon video-icon">
                                                   <i class="fa fa-edit" aria-hidden="true"></i><!-- /.fas fa-play -->
                                                </div><!-- /.course-details__icon -->
                                               <span style="font-size:20px;">Batch Will Start From:</span>
                                               <br/> <br/>
                                               <?php echo $row['cdate']; ?>
                                            </div><!-- /.course-details__curriculum-list-left -->
                                                                                        <!-- /.course-details__curriculum-list-right -->
                                        </li>
                                         <li>
                                            <div class="course-details__curriculum-list-left">
                                                <div class="course-details__meta-icon video-icon">
                                                    <i class="fas fa-clock"></i><!-- /.fas fa-play -->
                                                </div><!-- /.course-details__icon -->
                                               <span style="font-size:20px;">Batch Timing:</span>
                                               <br/> <br/>
                                               <?php echo $row['ctime']; ?>
                                            </div><!-- /.course-details__curriculum-list-left -->
                                                                                        <!-- /.course-details__curriculum-list-right -->
                                        </li>

                                        </ul>
                               </div><!-- /.course-details__tab-content -->
                    

                    <!-------- Show Reviews ------------>
                    <?php        
          $cid=$ftch['cid'];
$show="SELECT *  FROM comment where cid='$cid'";
$test = mysqli_query($conn,$show);
$find = mysqli_fetch_assoc($test);
 ?>

                    
                   <div class="tab-pane  animated fadeInUp" role="tabpanel" id="review">
                                    <div class="row">
                                        <div class="col-xl-7 d-flex">
                                          
                                        </div><!-- /.col-lg-8 -->
                                                                           </div><!-- /.row -->
                                    <div class="course-details__comment">
                                        <div class="course-details__comment-single">
                                            <div class="course-details__comment-top">
                                                                                                <div class="course-details__comment-right">
       <h2 class="course-details__comment-name"><?php echo $find['name']; ?></h2>
         <h6><?php echo $find['email']; ?></h6>

                                                    <!-- /.course-details__comment-name -->
                                                    <div class="course-details__comment-meta">
                       <p class="course-details__comment-date"><?php echo date("D_M_Y"); ?></p>                                                                                                                                                                   </div><!-- /.course-details__comment-meta -->
                                                </div><!-- /.course-details__comment-right -->
                                            </div><!-- /.course-details__comment-top -->
                                            <p class="course-details__comment-text"><?php echo $find['msg']; ?></p>
                                            <!-- /.course-details__comment-text -->
                                        </div><!-- /.course-details__comment-single -->
                                         

                                  </div><!-- /.course-details__comment -->
                                  
                                  
                         <!----- Review form ----->
                         
                         
       <form  class="course-details__comment-form" method="post">
                         <h2 class="course-details__title">Add a review</h2><!-- /.course-details__title -->
                <p class="course-details__comment-form-text">Review this Course.. <!-- /.course-details__coment-form-text -->
                                        <div class="row">
                                            <div class="col-lg-6">
                       <input type="text" placeholder="Your Name" name="name">
                       <input type="email" placeholder="Email Address" name="email">
                                            </div><!-- /.col-lg-6 -->
                                            <div class="col-lg-12">
                                                <textarea type="text" placeholder="Write Message" name="msg"></textarea>
     <button type="submit" name="btn" class="thm-btn course-details__comment-form-btn">Leave a
                                                    Review</button>
                                                    	<?php 
if(isset($_POST['btn'])){
 $name= $_POST['name'];
 $email = $_POST['email'];
$msg=$_POST['msg'];
$cid=$ftch['cid'];
$comnt ="INSERT INTO comment(cid,name,email,msg)values('$cid','$name','$email','$msg')"; 
$run= mysqli_query($conn,$comnt);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
	  }

	?>

                                            </div><!-- /.col-lg-12 -->
                                        </div><!-- /.row -->
                                    </form><!-- /.course-details__comment-form -->
                                </div><!-- /.course-details__tab-content -->
                            </div><!-- /.tab-content -->
                        </div><!-- /.course-details__content -->
                    </div><!-- /.col-lg-8 -->
 

                    <div class="col-lg-4">
                        <div class="course-details__price">
                            <p class="course-details__price-text">Course price </p><!-- /.course-details__price-text -->
                            <p class="course-details__price-amount"><?php echo $ftch['cfee']; ?></p><!-- /.course-details__price-amount -->
     <td><a href="enroll.php?enroll=<?php echo $ftch['cid']; ?>"  class="thm-btn course-details__price-btn">Buy This Course</a><!-- /.thm-btn -->
                        </div><!-- /.course-details__price -->

                        <div class="course-details__meta">
                            <a href="#" class="course-details__meta-link">
                                <span class="course-details__meta-icon">
                                    <i class="far fa-clock"></i><!-- /.far fa-clock -->
                                </span><!-- /.course-details__icon -->
                                Durations: <span><?php echo $ftch['cduration']; ?></span>
                            </a><!-- /.course-details__meta-link -->
                            <a href="#" class="course-details__meta-link">
                                <span class="course-details__meta-icon">
                                    <i class="far fa-folder-open"></i><!-- /.far fa-folder-open -->
                                </span><!-- /.course-details__icon -->
                                Lectures: <span>90</span>
                            </a><!-- /.course-details__meta-link -->
                            <a href="#" class="course-details__meta-link">
                                <span class="course-details__meta-icon">
                                    <i class="far fa-user-circle"></i><!-- /.far fa-user-circle -->
                                </span><!-- /.course-details__icon -->
                      
  
                                Students Enroll: <span>
<?php        
          $cname=$ftch['cname'];
          $teachby=$ftch['cteachby'];
$qry="SELECT COUNT(enrollid) AS total FROM enroll  where cname='$cname' AND cteachby='$teachby'";
$run = mysqli_query($conn,$qry);
$ftch = mysqli_fetch_assoc($run);
 $row=$ftch['total'];
 echo $row;
?>
</span>
                            </a><!-- /.course-details__meta-link -->
                            <a href="#" class="course-details__meta-link">
                                <span class="course-details__meta-icon">
                                    <i class="fas fa-play"></i><!-- /.fas fa-play -->
                                </span><!-- /.course-details__icon -->
                                Video: <span>1 hours</span>
                            </a><!-- /.course-details__meta-link -->
                                                                            </div><!-- /.course-details__list -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.course-details -->
         <?php include('footer.php'); ?>
    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
           <form  class="search-popup__form" action="search.php" method="post">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit" name="btnsearch"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
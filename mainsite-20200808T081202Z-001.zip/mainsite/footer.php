<footer class="site-footer">
            <div class="site-footer__upper">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-sm-12">
                            <div class="footer-widget footer-widget__contact">
                                <h2 class="footer-widget__title">Courses</h2><!-- /.footer-widget__title -->              <ul class="list-unstyled footer-widget__link-list">
                                        <li><a href="course.php">Photography</a></li>
                                        <li><a href="courses.php">Business</a></li>
                                        <li><a href="courses.php">SEO</a></li>
                                        <li><a href="courses.php">Languages</a></li>
                                          <li><a href="courses.php">Marketing </a></li>
                                    </ul><!-- /.footer-widget__link-list -->
                            </div><!-- /.footer-widget -->
                        </div><!-- /.col-lg-3 -->
                        <div class="col-xl-3 col-lg-6 col-sm-12">
                            <div class="footer-widget footer-widget__link">
                                <h2 class="footer-widget__title">Explore</h2><!-- /.footer-widget__title -->
                                <div class="footer-widget__link-wrap">
                                    <ul class="list-unstyled footer-widget__link-list">
                                        <li><a href="about.php">About</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                        <li><a href="teachers.php">Teachers</a></li>
                                        <li><a href="register.php">Join Us</a></li>
                                     <li><a href="faq.php">Help </a></li>
                                    </ul><!-- /.footer-widget__link-list -->
                                 </div><!-- /.footer-widget__link-wrap -->
                            </div><!-- /.footer-widget -->
                        </div><!-- /.col-lg-3 -->
                        <div class="col-xl-3 col-lg-6 col-sm-12">
                            <div class="footer-widget footer-widget__gallery">
                                <h2 class="footer-widget__title">Gallery</h2><!-- /.footer-widget__title -->
                                <ul class="list-unstyled footer-widget__gallery-list">
                                    <li><img src="assets/images/f1.jpg" alt=""></li>
                                    <li><img src="assets/images/f2.jpg" alt=""></li>
                                    <li><img src="assets/images/f3.jpg" alt=""></li>
                                    <li><img src="assets/images/f4.jpg" alt=""></li>
                                    <li><img src="assets/images/f5.jpg" alt=""></li>
                                    <li><img src="assets/images/f6.jpg" alt=""></li>
                                </ul><!-- /.footer-widget__gallery -->
                            </div><!-- /.footer-widget -->
                        </div><!-- /.col-lg-3 -->
                        <div class="col-xl-3 col-lg-6 col-sm-12">
                            <div class="footer-widget footer-widget__about">
                                <h2 class="footer-widget__title">About</h2><!-- /.footer-widget__title -->
                                <p class="footer-widget__text">TUTOR ONLINE has one simple objective: To bring tutors and students together</p><!-- /.footer-widget__text -->
                                <div class="footer-widget__btn-block">
                                    <a href="contact.php" class="thm-btn">Contact</a><!-- /.thm-btn -->
                                    <a href="register.php" class="thm-btn">Register</a><!-- /.thm-btn -->
                                </div><!-- /.footer-widget__btn-block -->
                            </div><!-- /.footer-widget -->
                        </div><!-- /.col-lg-3 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.site-footer__upper -->
            <div class="site-footer__bottom">
                <div class="container">
                    <p class="site-footer__copy">&copy; Copyright 2020 by <a href="index.php">tutoronline.com</a></p>
                    <div class="site-footer__social">
                        <a href="#" data-target="html" class="scroll-to-target site-footer__scroll-top"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
                        <a href="https://twitter.com/home"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/TutorOnline-107264741072039"><i class="fab fa-facebook-square"></i></a>
                        <a href="https://www.pinterest.com/business/hub/"><i class="fab fa-pinterest-p"></i></a>
                        <a href="https://www.instagram.com/tutoronine/"><i class="fab fa-instagram"></i></a>
                    </div><!-- /.site-footer__social -->
                    <!-- /.site-footer__copy -->
                </div><!-- /.container -->
            </div><!-- /.site-footer__bottom -->
        </footer><!-- /.site-footer -->
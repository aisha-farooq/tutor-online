<?php include('header.php'); ?>
        <section class="inner-banner" style=" background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                        <ul class="list-unstyled thm-breadcrumb">
                      <li style="font-size:50px;" ><a href="index.php">Home</a><a href="about.php" >&nbsp;>&nbsp;About</a></li>
                                  </ul><!-- /.list-unstyled -->
                            </div><!-- /.container -->

                          
        </section><!-- /.inner-banner -->
        <section class="about-one about-one__about-page">
            <img src="assets/images/circle-stripe.png" class="about-one__circle" alt="">
            <div class="container text-center">
                <div class="block-title text-center">
                    <h2 class="block-title__title">Lets do study with <br>
                        expert teachers</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="about-one__img">
                    <div class="row">
                        <div class="col-lg-6">
                            <img src="assets/images/aboutbody2.jpg" alt="">
                        </div><!-- /.col-lg-6 -->
                        <div class="col-lg-6">
                            <img src="assets/images/aboutbody.jpg" alt="">
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.row -->
                    <div class="about-one__review">
                        <p class="about-one__review-count counter">1467</p><!-- /.about-one__review-count -->
                        <div class="about-one__review-stars">
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                            <i class="fas fa-star"></i><!-- /.fa fa-star -->
                        </div><!-- /.about-one__stars -->
                        <p class="about-one__review-text">students loved us</p><!-- /.about-one__review-text -->
                    </div><!-- /.about-one__review -->
                </div><!-- /.about-one__img -->
                <p class="about-one__text">Tutoronline is a great option for people who want to build or
enhance skills. We have a variety of courses <br/>with multiple
learning styles. We offer free and paid instructional courses
on a variety of <br/>topics for professionals and students. If you
want to learn a new skill or  <br/> develop a current one, tutoronline
is a great option for learning. 
                  </p><!-- /.about-one__text -->
                <a href="courses.php" class="thm-btn about-one__btn">Start Learning Now</a><!-- /.thm-btn -->
            </div><!-- /.container -->
        </section><!-- /.about-one about-one__about-page -->
        
                
                       <section class="testimonials-one  ">
            <div class="container">
                <div class="block-title text-center">
                    <h2 class="block-title__title">What our students <br>
                        have to say</h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="testimonials-one__carousel owl-carousel owl-theme">
                                                      <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">Many of my coworkers choose to use tutoronline for continuing
education. I feel it has the best selection, training, and curriculum
vs others I have tried.</p>
                            <!-- /.testimonials-one__text -->
                            <img src="assets/images/s1 (1).jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Shane Vasquez</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">I have completed multiple courses so far and have been so informed as to the content of each course.Thank you tutoronline!!!</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/s1 (2).jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Maud Lee</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">tutoronline is the best E-learning platform I have ever used. The
courses at tutoronline are good. The professors of tutoronline are
also helpful.</p><!-- /.testimonials-one__text -->
                            <img src="assets/images/s2.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Barbara Kennedy</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                    <div class="item">
                        <div class="testimonials-one__single">
                            <div class="testimonials-one__qoute">
                                <img src="assets/images/qoute-1-1.png" alt="">
                            </div><!-- /.testimonials-one__qoute -->
                            <p class="testimonials-one__text">The best thing about tutoronline is the online courses offers through
the tutors from all over the world. you can explore more thing to
learn.</p>
                            <!-- /.testimonials-one__text -->
                            <img src="assets/images/s3.jpg" alt="" class="testimonials-one__img">
                            <h3 class="testimonials-one__name">Duane Carter</h3><!-- /.testimonials-one__name -->
                            <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                        </div><!-- /.testimonials-one__single -->
                    </div><!-- /.item -->
                                    </div><!-- /.testimonials-one__carousel owl-carousel owl-theme -->
            </div><!-- /.container -->
        </section><!-- /.testimonials-one -->
        
        
        <section class="cta-one cta-one__home-one" style="background-image:url('assets/images/accomplishment-ceremony-education-graduation-267885 (1).jpg')">
            <div class="container">
                <h2 class="cta-one__title">Tutor Online one & only <br>
                    mission is to extend <br>
                    your knowledge base</h2><!-- /.cta-one__title -->
                <div class="cta-one__btn-block">
                    <a href="courses.php" class="thm-btn cta-one__btn">Learn More</a><!-- /.thm-btn -->
                </div><!-- /.cta-one__btn-block -->
            </div><!-- /.container -->
        </section><!-- /.cta-one -->
        
        
          <?php include('footer.php'); ?>    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
            <form action="#" class="search-popup__form">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
<?php 
include('../studentadmin/conn.php');
if(empty($_SESSION['sname']))
{
     echo" <script> alert('Please Login First to Buy this Course.');</script>";  
     }
?>
<?php
	if($_GET){
	$cid = $_GET['enroll'];	
		$qry = "SELECT * from course where cid=$cid";
		$run = mysqli_query($conn,$qry); 
		$fetch=mysqli_fetch_array($run);	
	     $cname=$fetch['cname'];
		 $cteachby=$fetch['cteachby'];
		}
?>
<?php
$sname=$_SESSION['sname'];

		$qry = "SELECT * from student where sname='$sname'";
		$run = mysqli_query($conn,$qry); 
		$ftch=mysqli_fetch_array( $run);{	
		$semail=$ftch['semail'];
		}
		
   
      $status='trial';
      {
 $qry="INSERT INTO enroll(sname,semail,cname,cteachby,status)values('$sname','$semail','$cname','$cteachby','$status')";
    
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
 
  	 else
  	 {
  	 echo" <script> alert('You are Enrolled in Course!');</script>";

  	 }
  	 }
		
?>
      <?php include('header.php'); ?>    
         
 <section class="inner-banner" style="background-image:url('assets/images/mainbanner.jpg'); height:350px;">
            <div class="container">
                <ul class="list-unstyled thm-breadcrumb">
               <li style="font-size:50px;" ><a href="index.php">Home</a><a href="courses.php" >&nbsp;>&nbsp;Course</a></li>
                 
                </ul><!-- /.list-unstyled -->
                                
            </div><!-- /.container -->
             
        </section><!-- /.inner-banner -->
       
        <section class="course-one course-page">
        <div class="row">
          

          <div class="container">
<?php

    if(isset($_POST['btnsearch']))
	{	
	
		 $name= $_POST['search'];
		
		$qry = "select * from course where cmaincategory='$name' OR cname='$name'";
		$run = mysqli_query($conn,$qry);
		while($ftch = mysqli_fetch_array($run)){		  
	
				?>     <div class="col-lg-4" style="float:left">
                        <div class="course-one__single">
                            <div class="course-one__image">
                              <img src="<?php echo $ftch['cimage']; ?>" alt="">
                                <i class="far fa-heart"></i><!-- /.far fa-heart -->
                            </div><!-- /.course-one__image -->
                            <div class="course-one__content">
        <a href="#" class="course-one__category"><?php echo $ftch['cmaincategory']; ?></a><!-- /.course-one__category -->
                                <div class="course-one__admin">
  <?php        
$cteachby=$ftch['cteachby'];
$teachpic = "SELECT * FROM teacher WHERE tname = '$cteachby'";
$res = mysqli_query($conn,$teachpic);
$row = mysqli_fetch_array($res);

?>
                     <img src="<?php echo $row['timage']; ?>" alt="">
                                    by <a href="teachers.php"><?php echo $ftch['cteachby']; ?></a>
                                </div><!-- /.course-one__admin -->
                <h2 class="course-one__title"><a href="course-details.html"><?php echo $ftch['cname']; ?></a></h2>
                                <!-- /.course-one__title -->
                                <div class="course-one__stars">
                                    <span class="course-one__stars-wrap">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </span><!-- /.course-one__stars-wrap -->
                                    <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                                                    </div><!-- /.course-one__stars -->
                                <div class="course-one__meta">
     <a href="course-details.html"><i class="far fa-clock"></i> <?php echo $ftch['cduration']; ?></a>
                      <a href="course-details.html"><?php echo $ftch['cfee']; ?></a>
                                </div><!-- /.course-one__meta -->
 <a href="course-details.php?cid=<?php echo $ftch['cid']; ?> " class="course-one__link">See Preview</a><!-- /.course-one__link -->
                            </div><!-- /.course-one__content -->
                        </div><!-- /.course-one__single -->

      
              </div><!-- /.col-lg-4 -->
<?php 
}
}
?>

</div><!-- /.row -->

<div class="post-pagination" style="margin-left:550px;">
                    <a href="search.php"><i class="fa fa-angle-double-left"></i><!-- /.fa fa-angle-double-left --></a>
                    <a class="active" href="search.php">1</a>
                                        <a href="search.php"><i class="fa fa-angle-double-right"></i><!-- /.fa fa-angle-double-left --></a>
                </div><!-- /.post-pagination -->

            </div><!-- /.container -->
        </section><!-- /.course-one course-page -->
      <?php include('footer.php'); ?>

    </div><!-- /.page-wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div><!-- /.search-popup__overlay -->
        <div class="search-popup__inner">
            <form action="search.php" class="search-popup__form">
                <input type="text" name="search" placeholder="Type here to Search....">
                <button type="submit" name="search"><i class="kipso-icon-magnifying-glass"></i></button>
            </form>
        </div><!-- /.search-popup__inner -->
    </div><!-- /.search-popup -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/vegas.min.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- template scripts -->
    <script src="assets/js/theme.js"></script>
</body>

</html>
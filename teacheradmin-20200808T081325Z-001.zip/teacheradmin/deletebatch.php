<?php

	include('conn.php');

	if($_GET){
	$batchid=$_GET['delete'];
		
		$qry = "DELETE from batch where batchid='$batchid'";
		$run =mysqli_query($conn,$qry); 
		
		if(!$run){			
			mysqli_error($conn);
			}
			else
			{
				echo "Data deleted";
				}
				header('location:index.php');
			
		}	
	?>
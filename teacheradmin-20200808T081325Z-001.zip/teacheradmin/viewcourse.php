
<?php include('header.php');
 ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Tables</h1>
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Detail of Course You Teach</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="200%" cellspacing="0">
                  <thead>
                    <tr>
                     <th>Sr #</th>
                      <th>Course Category</th>
                      <th>Course Name</th>
                      <th>Course Detail</th>
                      <th>Course fee</th>
                      <th>Duration</th>   
                     
                      <th>Image</th>
                      <th>Status</th>
                      <th>Action</th>
                      <th >Manage Batch</th>
                  
                      
                    </tr>
                  </thead>
<?php
	$qry = "select * from course where cteachby='".$_SESSION['tname']."'";
	$run = mysqli_query($conn,$qry);
	$counter = 0;
	while($ftch = mysqli_fetch_array($run)){
		?>
	<tr>
<td><?php echo ++$counter; ?></td>
<td><?php echo $ftch['cmaincategory']; ?></td>
<td><?php echo $ftch['cname'];?></td>
<td>
<?php
echo substr($ftch['cdiscription'], 0 ,100);
?>
....
<a href="ftch.php?ftch=<?php echo $ftch['cid']; ?>">Read More</a> 
</td>

<td><?php echo $ftch['cfee']; ?></td>
<td><?php echo $ftch['cduration']; ?></td>
<td><img src="<?php echo $ftch['cimage']; ?>" width="50px" height="50px"></td>
<td><?php echo $ftch['status']; ?></td>
<td ><a href="cupdat.php?update=<?php echo $ftch['cid']; ?>" style="background-color:#022c46;  color:white;  padding: 8px 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-radius:6px;"><i class="fa fa-edit" aria-hidden="true"></i>&nbsp;Update</a>
  
<a href="delete.php?delete=<?php echo $ftch['cid']; ?>" onclick='checkdelete();' style="background-color: #f16101;  color:white;  padding: 8px 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-radius:6px;"><i class="fa fa-trash" aria-hidden="true"></i>&nbsp;Delete</a></td>

<td ><a href="addbatch.php?addbatch=<?php echo $ftch['cid']; ?>" style="background-color:#022c46;  color:white;  padding: 8px 8px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-radius:6px;"><i class="fa fa-users" aria-hidden="true"></i>&nbsp;Batch </a></td>
  
	</tr>
	<?php 
	
	};
?>
</table>
<script type="text/javascript">
 function checkdelete()
 {
	 confirm("Are you sure want to delete this"
	 );
 }
</script>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

          </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>


<!-- Modal -->


</body>

</html>

<?php include('header.php');?>
<?php   
 if(isset($_POST['submit']))
  {
  $cname=$_POST['cname'];
  $cteachby=$_POST['cteachby'];
  $cduration=$_POST['cduration'];
  $cdate=$_POST['cdate'];
   $ctime=$_POST['ctime'];
  $qry="INSERT INTO batch(cname,cteachby,cduration,cdate,ctime)values('$cname','$cteachby','$cduration','$cdate','$ctime')";
    
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
 else
 {
 header('location:index.php');
   } 
  }
  	  
?>  


<style>
label{
	color:black;
	font-size:larger;
}
</style>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Form</h1>
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4 ml-5 mr-5" >
<?php
	if($_GET){
	$cid = $_GET['addbatch'];	
		$qry = "SELECT * from course where cid=$cid";
		$run = mysqli_query($conn,$qry); 
		$ftch=mysqli_fetch_array($run);
		}	
		
	?>

<form class="ml-5 mt-5 mr-5" method="post" enctype="multipart/form-data">
 <h2 class="h3 mb-2 text-gray-800 mb-5">Add Course Batch Here</h2>
     <div class="form-group row">
    <label for="colFormLabelSm" class="col-sm-2 col-form-label ">Course Name</label>
    <div class="col-sm-8">
<input type="text" class="form-control form-control-sm" id="colFormLabelSm" name="cname" value="<?php echo $ftch['cname'];?>">

    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Teach By</label>
    <div class="col-sm-8">
<input type="text" class="form-control" id="colFormLabel" name="cteachby" value="<?php echo $ftch['cteachby'];?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Duration</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="colFormLabel" name="cduration" value="<?php echo $ftch['cduration'];?>">
    </div>
  </div>
<div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Starting From</label>
    <div class="col-sm-8">
      <input type="date" class="form-control" id="colFormLabel" name="cdate" >
    </div>
  </div>
<div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Timing</label>
    <div class="col-sm-8">
      <input type="time" class="form-control" id="colFormLabel" name="ctime" >
    </div>
  </div>



  <button type="submit"  name="submit" class="btn btn-lg mb-5" style="background-color:#022c46; color:white; margin-left:400px; margin-top:10px;"><i class="fa fa-users "></i>
ADD Batch</button>
</form>
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
 </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
 <script src="../ckeditor/ckeditor.js"></script>
  <script>
        CKEDITOR.replace( 'editor1' );
      </script>
</body>

</html>

<?php include('header.php');?>
<?php   

 if(isset($_POST['linkk']))
  {
 $cname=$_POST['cname'];
 $cteachby=$_POST['cteachby'];
  $linkk=$_POST['linkk'];
  	
  $query = "SELECT * FROM linkk WHERE cname= '$cname' AND cteachby='$cteachby'";
$result = mysqli_query($conn,$query);
if ($result) {
  if (mysqli_num_rows($result) > 0) 
  {
  $qryy = "UPDATE linkk set linkk='$linkk' where cname='$cname' AND cteachby='$cteachby'";

  }
   else
      {
$qry="INSERT INTO linkk (cname,cteachby,linkk)values('$cname','$cteachby','$linkk')";
    
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
 else
 header('location:index.php');
   } 
  }
  }		  
?>  


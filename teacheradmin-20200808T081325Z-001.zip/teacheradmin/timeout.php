 
<?php
include('conn.php');
	if($_GET){
	$id = $_GET['timeout'];	
		$qry = "SELECT * from task where id=$id";
		$run = mysqli_query($conn,$qry);
		$fetch_qry =mysqli_fetch_array($run);	
$fetch_qry['cdate'];
$timeout='Time Out';
	$qry = "UPDATE task set cdate='$timeout' where id='$id'";
		$run = mysqli_query($conn,$qry);
		if(!$run){
			mysqli_error($conn);
			}
			else
			{
		
				 header('location:viewtask.php');
				}
				
	}
	
	
	
?>

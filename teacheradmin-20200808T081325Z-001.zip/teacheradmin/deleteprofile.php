<?php

	include('conn.php');

	if($_GET){
	$tid=$_GET['delete'];
		
		$qry = "DELETE from teacher where tid='$tid'";
		$run =mysqli_query($conn,$qry); 
		
		if(!$run){			
			mysqli_error($conn);
			}
			else
			{
				echo "Data deleted";
				}
				header('location:../index.php');
			
		}	
	?>
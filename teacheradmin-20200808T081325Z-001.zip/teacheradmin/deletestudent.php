<?php

	include('conn.php');

	if($_GET){
	$enrollid=$_GET['delete'];
		
		$qry = "DELETE from enroll where enrollid='$enrollid'";
		$run =mysqli_query($conn,$qry); 
		
		if(!$run){			
			mysqli_error($conn);
			}
			else
			{
				echo "Data deleted";
				}
				header('location:index.php');
			
		}	
	?>
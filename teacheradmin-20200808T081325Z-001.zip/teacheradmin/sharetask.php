<?php include('header.php');?>
<?php   

 if(isset($_POST['submit']))
  {
 $cname=$_POST['cname'];
  $cteachby=$_POST['cteachby'];
    $taskname=$_POST['taskname'];
 $cdate=$_POST['cdate'];
 $filee ="../pic/".$_FILES['filee']['name'];
move_uploaded_file($_FILES['filee']['tmp_name'],$filee);

 $qry="INSERT INTO task (cname,cteachby,taskname,cdate,filee)values('$cname','$cteachby','$taskname','$cdate','$filee')";
    
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
 else
 {
 header('location:index.php');
 }
   } 

 	  
?>  



           <style>
label
{
	color:black;
}
.radio{
	width:25px;
	height:20px;
	}
</style>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Share Task</h6>
            </div>
 
	<form class="mt-5 mr-5" method="post" enctype="multipart/form-data" >
   <div class="form-group row" style="margin-left:200px;">
   <label for="colFormLabelSm">Choose Course:</label>
 <div class="col-sm-8" style="margin-left:50px;">  
<select  id="course" autofocus="autofocus" required  style="width:350px;" class="form-control" 
     name="cat">
		  <option value="">Select Category</option>
		    <?php
		   $cteachby=$_SESSION['tname'];
		    $result = mysqli_query($conn,"SELECT * FROM course where cteachby='$cteachby'");
			while($row = mysqli_fetch_array($result)) {
			?>
				<option value="<?php echo $row["cname"];?>"><?php echo $row["cname"];?></option>
			<?php 
			}
			echo $name=$ftch['cname'];
			?>
			
		  </select>
  </div>
</div>
              <div class="table-responsive ml-2">
  <table class="table table-bordered" id="dataTable"  cellspacing="0" >
                 	</table>

</div>  



<button type="button"   onclick="GetSelectedText()" data-toggle="modal" data-target="#exampleModalCenter" class="btn btn-lg mb-5" name="btn" style="background-color:#022c46; color:white; margin-left:450px; margin-top:10px;"><i class="fa fa-tasks "></i>&nbsp;Share Task</button>
</form>

	
	

                      </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

          </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script>
$(document).ready(function() {
	$('#course').on('change', function() {
			var cname = this.value;
			$.ajax({
				url: "ajaxtaskdata.php",
				type: "POST",
				data: {
					cname:cname
				},
				cache: false,
				success: function(dataResult){
					$("#dataTable").html(dataResult);
				}
			});
		
		
	});
});
</script>
<script>

		function GetSelectedText(){
				var e = document.getElementById("course");
				var result = e.options[e.selectedIndex].text;

				document.getElementById("result").value = result;
							}

		</script>

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Add Task/Assignment Here</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
          <form method="post" enctype="multipart/form-data">
      <div class="modal-body"> 
  <div class="form-group">
    <label >Course Name</label>
    <input type="text" class="form-control"  aria-describedby="emailHelp" id="result" name="cname">    
  </div>
   <div class="form-group">
    <label >Teacher Name</label>
    <input type="text" class="form-control"  aria-describedby="emailHelp" id="result" name="cteachby" value="<?php echo $cteachby; ?>"> 
  </div>
  <div class="form-group">
    <label >Task name</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name="taskname">
  </div>
  <div class="form-group">
    <label >Last Date:</label>
    <input type="date" class="form-control" id="exampleInputPassword1" name="cdate">
  </div>
  <div class="form-group">
    <label >Upload Task File:</label>
    <input type="file" class="form-control"  name="filee" >
  </div>
   
 


   <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="submit">Share</button>
      </div>      
    </div>
     </form>
  </div>
</div>
</div>

	</body>

</html>

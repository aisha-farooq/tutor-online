<?php
include('conn.php');
	if($_GET){
	$enrollid = $_GET['status'];	
		$qry = "SELECT * from enroll where enrollid=$enrollid";
		$run = mysqli_query($conn,$qry); 
		$fetch_qry =mysqli_fetch_array($run);
		$fetch_qry['status'];	
		$status='student';
		$qry = "UPDATE enroll set status='$status'where enrollid='$enrollid'";
		$run = mysqli_query($conn,$qry);
		if(!$run){
			mysqli_error($conn);
			}
			else
			{
				header('location:index.php');
				
				}
				
	}
	
	?>

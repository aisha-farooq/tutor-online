 <?php
 error_reporting(0);
   session_start();
      $conn= mysqli_connect('localhost','root','','tutoronline');

if(!$conn){
	
	mysqli_error($conn);
	
}

?>

<?php include('header.php');
 ?>
  <div class="table-responsive ml-2">
  <table class="table table-bordered" id="table"  cellspacing="0" >

          
              <thead>
                    <tr>
                     <th>Sr #</th>
                      <th>Course Name</th>
                      <th>Student Name</th>
                      <th>Student Email</th>
                                           
                    </tr>
                  </thead>
<?php
	$cname=$_POST["cname"];

	$qry = "select * from enroll where cteachby='".$_SESSION['tname']."' AND cname='$cname' AND status='student'";
	$run = mysqli_query($conn,$qry);
	$counter = 0;
	while($ftch = mysqli_fetch_array($run)){
		?>
	<tr>
<td><?php echo ++$counter; ?></td>
<td><?php echo $ftch['cname']; ?></td>
<td><?php echo $ftch['sname'];?></td>
<td><?php echo $ftch['semail'];?></td>

	</tr>
	<?php 
	
	};
?>
</table>
</div>
     

     
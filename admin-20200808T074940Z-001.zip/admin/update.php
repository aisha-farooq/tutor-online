           <style>
.main{
height: 600px;
width: 380px;
margin-top:35px;
margin-left:320px;
margin-bottom: auto;
background:#022c46;
position: relative;
display: flex;
justify-content: center;
flex-direction: column;
padding: 10px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
border-radius: 5px;
}
input{
	height:30px;
	width:200px;
	border:none;
	border-radius:5px;
	margin-left:5px;
}
.in{
	margin-top:20px;
}
.inn{
	margin-top:10px;
}

label
{
	color:white;
}
h1{
	color:#f16101;
	margin-left:110px;
	
}
.login_btn {
		margin-top:50px;
		margin-left:65px;
			width: 60%;
			height:35px;
			background:  #f16101 !important;
			color: white !important;
			border:none;
			border-radius:5px;
		}
.radio{
	width:25px;
	height:20px;
	margin-left:20px;
	margin-top:5px;
}
</style>


<?php include('header.php');
 ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Update Here</h6>
            </div>
 
<?php
	if($_GET){
	$tid = $_GET['update'];	
		$qry = "SELECT * from teacher where tid=$tid";
		$run = mysqli_query($conn,$qry); 
		$fetch_qry =mysqli_fetch_array($run);	
	?>
	<div class="main">
	<h1>Update</h1>
	<form method="post" enctype="multipart/form-data">
	<label>First Name</label>&nbsp;
	<input type="text" name="tname" class="inn"value="<?php echo $fetch_qry['tname']; ?>" />
	<br /> 
	<label>Last Name</label>&nbsp;&nbsp;
	<input type="text" name="tlastname" class="in"value="<?php echo $fetch_qry['tlastname']; ?>" />
		<br />
		<label>Email </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="text" name="temail" class="in"value="<?php echo $fetch_qry['temail']; ?>" />
		<br />
<label>Password</label>&nbsp;&nbsp;&nbsp;
	<input type="text" name="tpwd" class="in"value="<?php echo $fetch_qry['tpwd']; ?>" />
		<br />
<label>Introduction</label>
	<input type="text" name="tintro" class="in" value="<?php echo $fetch_qry['tintro']; ?>" />
		<br />
          Male    	 
	    <input type="radio" class="radio" name="tgender" value="male" <?php if($fetch_qry['tgender']=="male"){ echo "checked";}?> style="margin-left:35px;"/><br/>
Female
<input type="radio" name="tgender" class="radio"value="female" <?php if($fetch_qry['tgender']=="female"){ echo"checked";}?> />       
<br/>     
<label>Image</label>
	<input type="file" name="timage" class="in" value="<?php echo $fetch_qry['timage']; ?>" />
		<br />
           <label>Country</label>
	<input type="text" name="tcountry" class="in" value="<?php echo $fetch_qry['tcountry']; ?>" />
		<br />
          

	<input type="submit" name="btn"  value="Update" class="login_btn" />
</form>
	</div>
	
	<?php
	
	if(isset($_POST['btn'])){
	
		$tname= $_POST['tname'];
		$tlastname = $_POST['tlastname'];
		$temail = $_POST['temail'];
		$tpwd = $_POST['tpwd'];
		$tintro = $_POST['tintro'];
		$tgender= $_POST['tgender'];
		$timage = "../pic/".$_FILES['timage']['name'];
	move_uploaded_file($_FILES['timage']['tmp_name'],$timage);
	$tcountry= $_POST['tcountry'];

$qry = "UPDATE teacher set tname='$tname',tlastname='$tlastname',temail='$temail',tpwd='$tpwd', tintro='$tintro', tgender='$tgender',timage='$timage' ,tcountry='$tcountry' where tid='$tid'";
		$run = mysqli_query($conn,$qry);
		if(!$run){
			mysqli_error($conn);
			}
			else
			{
				header('location:teachertable.php');
				
				}
				
	}
	
	}
	
?>


                      </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

          </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>

<?php
include('conn.php');
	if($_GET){
	$cid = $_GET['delete'];	
		$qry = "SELECT * from course where cid=$cid";
		$run = mysqli_query($conn,$qry); 
		$fetch_qry =mysqli_fetch_array($run);
		$fetch_qry['status'];	
		$status='Disapprove';
		$qry = "UPDATE course set status='$status'where cid='$cid'";
		$run = mysqli_query($conn,$qry);
		if(!$run){
			mysqli_error($conn);
			}
			else
			{
				header('location:index.php');
				
				}
				
	}
	
	?>

<?php

	include('conn.php');

	if($_GET){
	$sid=$_GET['delete'];
		
		$qry = "DELETE from student where sid='$sid'";
		$run =mysqli_query($conn,$qry); 
		
		if(!$run){			
			mysqli_error($conn);
			}
			else
			{
				echo "Data deleted";
				}
				header('location:studenttable.php');
			
		}	
	?>
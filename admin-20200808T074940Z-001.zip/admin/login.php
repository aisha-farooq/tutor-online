<?php 
include('conn.php');
if(isset($_POST['submit'])){
$uname= $_POST['uname'];
$pwd = $_POST['pwd'];
$login = "SELECT * FROM admin WHERE uname = '$uname' && pwd = '$pwd'";
$result = mysqli_query($conn,$login);
$row = mysqli_fetch_array($result);

  
  if($row['uname']==$uname and $row['pwd']==$pwd){
       $_SESSION['uname'] = $row['uname'];


  
      header("location:index.php");
  } 
  else{
  
     echo" <script> alert('You Enter Wrong Username or Password');</script>";
   
  }
}
?>
<style>
body {
 background-image: linear-gradient(#1a1b4a,#fb661e );
}
.user_card {
height: 400px;
width: 380px;
margin-top: 120px;
margin-left:480px;
margin-bottom: auto;
background:#022c46;
position: relative;
display: flex;
justify-content: center;
flex-direction: column;
padding: 10px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
border-radius: 5px;
}
		.brand_logo_container {
			position: absolute;
			height: 150px;
			width: 150px;
			top: -75px;
			border-radius: 50%;
			background:  #f16101;
			padding: 10px;
			text-align: center;
			margin-left:100px;
		}
		.brand_logo {
			height: 150px;
			width: 150px;
			border-radius: 50%;
			border: 2px solid white;
		}
		.form_container {
			margin-top: 100px;
		}
		input{
	height:40px;
	width:320px;
	margin-top:15px;
	margin-left:25px;
border:thin gray solid;
	padding:5px;
	border-radius:5px;
	
}
		.login_btn {
		margin-top:50px;
		margin-left:65px;
			width: 60%;
			height:35px;
			background:  #f16101 !important;
			color: white !important;
			border:none;
			border-radius:5px;
		}
			</style>

<body>
  <div class="container" >

    <div class="container h-100 mb-5">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="../mainsite/assets/images/loginn.png"class="brand_logo" alt="Logo">
					</div>
				</div>
				<div class="d-flex justify-content-center form_container">
					<form action=" "method="post">
									<div class="input-group ">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" name="uname" class="form-control input_user" value="" placeholder="username">
						</div>
						<div class="input-group mb-2 ">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" name="pwd" class="form-control input_pass" value="" placeholder="password">
						</div>
						<div class="form-group">
													</div>
							<div class="d-flex justify-content-center mt-3 login_container">
				 	<button type="submit" name="submit" class="btn login_btn">Login</button>
				 	<h6  style=" margin-left:70px; font-size:large;">Forget Password?<a href="../forgetpwd/adforgetpwd.php" >Click Here!</a></h6>
				   </div>
					</form>
				</div>
		
			</div>
		</div>
	</div>
        
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
 <script type="text/javascript">
    function validate() {
        var $valid = true;
        document.getElementById("uname").innerHTML = "";
        document.getElementById("pwd").innerHTML = "";
        
        var userName = document.getElementById("uname").value;
        var password = document.getElementById("pwd").value;
        if(userName == "") 
        {
            document.getElementById("uname").innerHTML = "required";
        	$valid = false;
        }
        if(password == "") 
        {
        	document.getElementById("pwd").innerHTML = "required";
            $valid = false;
        }
        return $valid;
    }
    </script>

<?php
include('conn.php');
 $token=$_GET['token'];
$query =mysqli_query($conn,"SELECT * FROM  teacher where token='$token'");
$ftch=mysqli_fetch_array($query);
 $tpwd=$ftch['tpwd'];
 ?>

<?php 

if(isset($_POST['submit'])){

$pasword=$_POST['pwd'];
$rpasword=$_POST['rpwd'];

      if ($pasword == $rpasword ){
               
      $update="update  teacher set tpwd='$rpasword' where token='$token'";
     $run = mysqli_query($conn,$update);
 if($run){
      echo "<script >alert('Password is Reset.');</script>";     header('location:../mainsite/index.php');
     }
   
   else 
   {
   echo "<script type='text/javascript'>alert('Password is not Matched');</script>";

   }
     
     }
     }
		
?>
<style>
body {
 background-image: linear-gradient(#1a1b4a,#fb661e );
}
.user_card {
height: 400px;
width: 380px;
margin-top: 120px;
margin-left:480px;
margin-bottom: auto;
background:#022c46;
position: relative;
display: flex;
justify-content: center;
flex-direction: column;
padding: 10px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
border-radius: 5px;
}
		.brand_logo_container {
			position: absolute;
			height: 150px;
			width: 150px;
			top: -75px;
			border-radius: 50%;
			background:  #f16101;
			padding: 10px;
			text-align: center;
			margin-left:100px;
		}
		.brand_logo {
			height: 150px;
			width: 150px;
			border-radius: 50%;
			border: 2px solid white;
		}
		.form_container {
			margin-top: 100px;
		}
		input{
	height:40px;
	width:320px;
	margin-top:15px;
	margin-left:25px;
border:thin gray solid;
	padding:5px;
	border-radius:5px;
	
}
		.login_btn {
		margin-top:50px;
		margin-left:65px;
			width: 60%;
			height:35px;
			background:  #f16101 !important;
			color: white !important;
			border:none;
			border-radius:5px;
		}
			</style>

<body>
  <div class="container" >

    <div class="container h-100 mb-5">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="../mainsite/assets/images/loginn.png"class="brand_logo" alt="Logo">
					</div>
				</div>
				<div class="d-flex justify-content-center form_container">
					<form method="post">
									<div class="input-group ">
								<div class="input-group mb-2 ">
							<div class="input-group-append">
	<label style="color:white; margin-left:35px; font-size:25px;" >Enter New Password..</label>							</div>
		<input type="password" name="pwd" class="form-control input_pass" value="" placeholder="Type Password...">
						<br/>
						<input type="password" name="rpwd" class="form-control input_pass" value="" placeholder="Retype Password..">
						</div>

		<button type="submit" name="submit" class="btn login_btn">Reset Password</button>
				   </div>
					</form>
				</div>
		
			</div>
		</div>
	</div>
        
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../mainsite/vendor/jquery/jquery.min.js"></script>
  <script src="../mainsite/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../mainsite/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../mainsite/js/sb-admin-2.min.js"></script>

</body>

</html>
 <script type="text/javascript">
    function validate() {
        var $valid = true;
        document.getElementById("uname").innerHTML = "";
        document.getElementById("pwd").innerHTML = "";
        
        var userName = document.getElementById("uname").value;
        var password = document.getElementById("pwd").value;
        if(userName == "") 
        {
            document.getElementById("uname").innerHTML = "required";
        	$valid = false;
        }
        if(password == "") 
        {
        	document.getElementById("pwd").innerHTML = "required";
            $valid = false;
        }
        return $valid;
    }
    </script>

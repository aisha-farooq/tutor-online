
<!DOCTYPE html>
<html>
<body>

      <?php 
if(isset($_POST['btn'])){
 $name= $_POST['name'];
 $email = $_POST['email'];
$msg=$_POST['msg'];
}
	?><?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = '0';                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
  $mail->Username = 'shahzonaashraf@gmail.com';
$mail->Password = 'zoni123@123';
                              // SMTP password
    $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = '587';                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
   $mail->setFrom('shahzonaashraf@gmail.com','Tutor Online');
    $mail->addAddress("shahzonaashraf@gmail.com");    // Add a recipient// Name is optional
       // 
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'USERS REQUEST';
     $mail->Body    = " $name "." $email &nbsp; &nbsp;"."$msg";   
    $mail->send();
 
    echo  header('location:mainsite/contact.php');
} catch (Exception $e)
 {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?> 
 <!-- Bootstrap core JavaScript-->
  <script src="../mainsite/vendor/jquery/jquery.min.js"></script>
  <script src="../mainsite/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../mainsite/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../mainsite/js/sb-admin-2.min.js"></script>


</body>
</html>
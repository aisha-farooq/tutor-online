           <style>

label
{
	color:Black;
}
h1{
	color:#f16101;
	margin-left:110px;
	
}
.radio{
	width:25px;
	height:20px;
		
}
</style>


<?php include('header.php');
 ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Update Here</h6>
            </div>
 
<?php
	if($_GET){
	$sid = $_GET['update'];	
		$qry = "SELECT * from student where sid=$sid";
		$run = mysqli_query($conn,$qry); 
		$fetch_qry =mysqli_fetch_array($run);	
	?>
	<div>
	
	<form class="ml-5 mt-5 mr-5" method="post" enctype="multipart/form-data">
	<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Teacher Name</label>
    <div class="col-8">
	<input type="text" name="sname" value="<?php echo $fetch_qry['sname']; ?>"  class="form-control form-control-sm" id="colFormLabelSm"/>
	</div>
	</div>
	<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Last Name</label>
    <div class="col-8">
	<input type="text" name="slastname" value="<?php echo $fetch_qry['slastname']; ?>" class="form-control form-control-sm" id="colFormLabelSm"/>
	</div></div>
		<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Email</label>
    <div class="col-8">
	<input type="text" name="semail" value="<?php echo $fetch_qry['semail']; ?>"class="form-control form-control-sm" id="colFormLabelSm" />
		</div></div>
<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Password</label>
    <div class="col-8">
	<input type="text" name="spwd" value="<?php echo $fetch_qry['spwd']; ?>" class="form-control form-control-sm" id="colFormLabelSm"/>
		</div></div>
<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Discription</label>
    <div class="col-8">
<textarea class="form-control dis ckeditor" name="editor1" class="form-control form-control-sm" id="colFormLabelSm"><?php echo $fetch_qry['sintro']; ?></textarea>
</div>
</div>

     

<div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label">Image</label>
    <div class="col-8">
<input type="file" name="simage" class="form-control form-control-sm " id="colFormLabelSm" value="<?php echo $fetch_qry['simage']; ?>" />
		</div></div>	
     <div class="form-group row">
    <label for="colFormLabelSm" class="col-2 col-form-label ">Country</label>
    <div class="col-8">
	<input type="text" name="scountry" class="form-control form-control-sm " id="colFormLabelSm"value="<?php echo $fetch_qry['scountry']; ?>" />
	</div></div>

<div class="form-group row">
<label for="colFormLabelSm" class="col-2 col-form-label">Male</label>
       <div class="col-8">	  
	    <input type="radio" class="radio" name="sgender" value="male" <?php if($fetch_qry['sgender']=="male"){ echo "checked";}?>  class="form-control form-control-sm" id="colFormLabelSm"/>
	    </div></div>
	   
	    <div class="form-group row">
	    <label for="colFormLabelSm" class="col-2 col-form-label">Female</label>
    <div class="col-8">	
<input type="radio" name="sgender" class="radio"value="female" <?php if($fetch_qry['sgender']=="female"){ echo"checked";}?> class="form-control form-control-sm" id="colFormLabelSm"/>       
<div></div>
    
	  <button type="submit"  name="btn" class="btn btn-lg mb-5" style="background-color:#022c46; color:white; margin-left:250px; margin-top:20px; padding:10px;">Update</button>	
</form>
	</div>
	
	<?php
	
	if(isset($_POST['btn'])){
	
		$sname= $_POST['sname'];
		$slastname = $_POST['slastname'];
		$semail = $_POST['semail'];
		$spwd = $_POST['spwd'];
		$sintro = $_POST['editor1'];
		$sgender= $_POST['sgender'];
		$simage = "../pic/".$_FILES['simage']['name'];
	move_uploaded_file($_FILES['simage']['tmp_name'],$simage);
	$scountry= $_POST['scountry'];
$qry = "UPDATE student set sname='$sname',slastname='$slastname',semail='$semail',spwd='$spwd', sintro='$sintro', sgender='$sgender',simage='$simage' ,scountry='$scountry' where sid='$sid'";
		$run = mysqli_query($conn,$qry);
		if(!$run){
			mysqli_error($conn);
			}
			else
			{
			echo "updated";
				
				}
				
	}
	
	}
	
?>


                      </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

          </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
<script src="../ckeditor/ckeditor.js"></script>
  <script>
        CKEDITOR.replace( 'editor1' );
      </script>

</body>

</html>


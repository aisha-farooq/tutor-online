<style>
label{
	color:black;
	font-size:larger;
}
</style>
<?php include('header.php');?>
<?php   
 if(isset($_POST['submit']))
  {
 $cmaincategory=$_POST['cmaincategory'];
  $cname=$_POST['cname'];
  $cteachby=$_POST['cteachby'];
 $cdiscription=$_POST['editor1'];
 $cfee=$_POST['cfee'];
$cduration=$_POST['cduration'];
$status='pending';
$cimage = "../pic/".$_FILES['cimage']['name'];
	move_uploaded_file($_FILES['cimage']['tmp_name'],$cimage);

	  
	  $query = "SELECT * FROM course WHERE cname= '$cname'";
$result = mysqli_query($conn,$query);
if ($result) {
  if (mysqli_num_rows($result) > 0) 
  {
   echo" <script> alert('This course is already registered by you');</script>";

  }
   else
      {
$qry="INSERT INTO course(cmaincategory,cname,cteachby,cdiscription,cfee,cduration,status,cimage)values('$cmaincategory','$cname','$cteachby','$cdiscription','$cfee','$cduration','$status','$cimage')";
    
  $run= mysqli_query($conn,$qry);
  if(!$run)
	  {
		  echo	mysqli_error($conn) ;
	  }
 
   } 
  }
  }		  
?>  

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php
    include('sidebar.php');
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php include('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Form</h1>
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4 ml-5 mr-5" >

<form class="ml-5 mt-5 mr-5" method="post">
 <h2 class="h3 mb-2 text-gray-800 mb-5">Add Course Here</h2>
   <div class="form-group row">
   <label for="colFormLabelSm">Choose Main Category of Your Course</label>
 <div class="col-sm-8" style="margin-left:150px;">  
  <select class="form-control form-control-sm" id="sel1" name="cmaincategory">
    <option>SEO</option>
    <option>DESIGN</option>
    <option>MARKETING</option>
    <option>BUSINESS</option>
    <option>LANGUAGES</option>
    <option>IT & SOFTWARE</option>
    <option>DEVELOPMENT</option>
    <option>PHOTOGRAPHY</option>
  </select>
  </div>
</div>  
  <div class="form-group row">
    <label for="colFormLabelSm" class="col-sm-2 col-form-label ">Course Name</label>
    <div class="col-sm-8">
      <input type="text" class="form-control form-control-sm" id="colFormLabelSm" name="cname">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Teach By</label>
    <div class="col-sm-8">
<input type="text" class="form-control" id="colFormLabel" name="cteachby" value="<?php echo $_SESSION['tname'];?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label ">Course Detail</label>
    <div class="col-sm-8">
      <textarea class="form-control dis ckeditor" name="editor1" ></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Course Image</label>
    <div class="col-sm-8">
      <input type="file" class="form-control" id="colFormLabel" name="cimage">
    </div>
  </div>

    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Fee</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="colFormLabel" name="cfee">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Duration</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="colFormLabel" name="cduration">
    </div>
  </div>

  <button type="submit"  name="submit" class="btn btn-lg mb-5" style="background-color:#022c46; color:white; margin-left:450px; margin-top:10px;">ADD Course</button>
</form>
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Tutor Online</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
 </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
 <script src="../ckeditor/ckeditor.js"></script>
  <script>
        CKEDITOR.replace( 'editor1' );
      </script>
</body>

</html>

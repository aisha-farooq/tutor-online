<?php

	include('conn.php');

	if($_GET){
	$cid=$_GET['delete'];
		
		$qry = "DELETE from course where cid='$cid'";
		$run =mysqli_query($conn,$qry); 
		
		if(!$run){			
			mysqli_error($conn);
			}
			else
			{
				echo "Data deleted";
				}
				header('location:viewcourse.php');
			
		}	
	?>
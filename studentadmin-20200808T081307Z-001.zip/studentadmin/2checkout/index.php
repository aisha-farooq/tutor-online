<html>
<head>
<style>
.user_card {
height: 600px;
width: 500px;
margin-top:120px;
margin-left:460px;
margin-bottom: auto;
background:#022c46;
position: relative;
display: flex;
justify-content: center;
flex-direction: column;
padding: 10px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
border-radius: 5px;
}
			input{
	height:40px;
	width:320px;
	margin-top:15px;
	
border:thin gray solid;
	padding:5px;
	border-radius:5px;
	
}
.brand_logo {
			height: 250px;
			width: 250px;
			border-radius: 50%;
			border: 2px solid white;
			margin-bottom:5px;
			margin-top:-210px;
			margin-left:120px;
			
		
		}

		.btn {
		margin-top:50px;
		margin-left:95px;
			width: 60%;
			height:35px;
			background:  #f16101 !important;
			color: white !important;
			border:none;
			border-radius:5px;
		}
		label{
	color:white;
}
			</style>


</head>
<?php include('conn.php'); ?>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- 2Checkout JavaScript library -->
<script src="https://www.2checkout.com/checkout/api/2co.min.js"></script>

<script>
// Called when token created successfully.
var successCallback = function(data) {
  var myForm = document.getElementById('paymentFrm');
  
  // Set the token as the value for the token input
  myForm.token.value = data.response.token.token;
  
  // Submit the form
  myForm.submit();
};

// Called when token creation fails.
var errorCallback = function(data) {
  if (data.errorCode === 200) {
    tokenRequest();
  } else {
    alert(data.errorMsg);
  }
};

var tokenRequest = function() {
  // Setup token request arguments
  var args = {
    sellerId: "250437764913",
    publishableKey: "A6C7D2F0-811A-45BC-A4DA-317A76C7D795",
    ccNo: $("#card_num").val(),
    cvv: $("#cvv").val(),
    expMonth: $("#exp_month").val(),
    expYear: $("#exp_year").val()
  };
  
  // Make the token request
  TCO.requestToken(successCallback, errorCallback, args);
};

$(function() {
  // Pull in the public encryption key for our environment
  TCO.loadPubKey('sandbox');
  
  $("#paymentFrm").submit(function(e) {
    // Call our token request function
    tokenRequest();
   
    // Prevent form from submitting
    return false;
  });
});
</script>
<body>

<div class="payment-frm">
 
   
      <form id="paymentFrm" method="post" action="paymentSubmit.php" class="user_card" >
       
    <div class="brand_logo_container">
	<img src="../../mainsite/assets/images/check.png" class="brand_logo" alt="Logo" >
	</div>
        <div>
            <label>NAME</label>
            <input type="text" name="name" id="name" placeholder="Enter name" required autofocus style="margin-left:100px; ">
        </div>
        <div>
            <label>EMAIL</label>
            <input type="email" name="email" id="email" placeholder="Enter email" required style="margin-left:100px;">
        </div>
        <div>
            <label>CARD NUMBER</label>
            <input type="text" name="card_num" id="card_num" placeholder="Enter card number" autocomplete="off" required style="margin-left:30px;">
        </div>
        <div>
            <label><span>EXPIRY DATE</span></label>
            <input type="number" name="exp_month" id="exp_month" placeholder="MM" required style="margin-left:50px;">
            <input type="number" name="exp_year" id="exp_year" placeholder="YY" required style="margin-left:150px;">
        </div>
        <div>
            <label>CVV</label>
            <input type="number" name="cvv" id="cvv" autocomplete="off" required style="margin-left:150px;">
        </div>
        
        <!-- hidden token input -->
        <input id="token" name="token" type="hidden" value="">
        
        <!-- submit button -->
        <input type="submit" class="btn btn-success" value="Submit Payment">
    </form>
</div>
</body>
</html>